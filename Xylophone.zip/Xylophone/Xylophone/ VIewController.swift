//
//  ViewController.swift
//  Xylophone
//
//  Created by Hassan Mostafa on 11/16/17.
//  Copyright © 2018 Hassan Mostafa. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController{
    
    let soundArray = ["note1", "note2", "note3", "note4", "note5", "note6", "note7"]
    var selectedNote: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
    }



    @IBAction func notePressed(_ sender: UIButton) {
          selectedNote = soundArray[sender.tag - 1]
//        print(sender.tag)
        playSound()
    }
    
    
    
//    var player: AVAudioPlayer?
    var player = AVAudioPlayer()
    
   
    func playSound() {
        let url = Bundle.main.url(forResource: selectedNote, withExtension: "wav")!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.play()
            
        } catch {
            print(error)
        }
    }

}

