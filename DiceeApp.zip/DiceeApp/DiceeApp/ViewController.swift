//
//  ViewController.swift
//  DiceeApp
//
//  Created by Hassan Mostafa on 1/1/18.
//  Copyright © 2018 Hassan Mostafa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var diceRandom1 = 0
    var diceRandom2 = 0
    let diceArray = ["dice1", "dice2", "dice3", "dice4", "dice5", "dice6"]
// outLets
    @IBOutlet weak var diceImageView1: UIImageView!
    @IBOutlet weak var diceImageView2: UIImageView!
    @IBOutlet weak var phoneScoreTextField: UITextField!
    @IBOutlet weak var playerScoreTextField: UITextField!
    @IBOutlet weak var winnerLabel: UILabel!
    
    // Actions
    
    @IBAction func rollButtonAction(_ sender: UIButton) {
        diceRandom1 = Int(arc4random_uniform(6))
        diceRandom2 = Int(arc4random_uniform(6))
        diceImageView1.image = UIImage(named: diceArray[diceRandom1])
        diceImageView2.image = UIImage(named: diceArray[diceRandom2])
        phoneScoreTextField.text = String(diceRandom1 + 1)
        playerScoreTextField.text = String(diceRandom2 + 1)
        
        if diceRandom1 > diceRandom2 {
            winnerLabel.text = "IPhone"
        }
        else if diceRandom2 > diceRandom1 {
             winnerLabel.text = "Player"
        }
        else {
             winnerLabel.text = "Equal"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

